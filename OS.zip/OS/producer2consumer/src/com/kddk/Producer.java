package com.kddk;

import java.util.LinkedList;

public class Producer implements Runnable {

	Buffer bf = new Buffer();	
	int maxsize = bf.getMaxsize();
	LinkedList<Object> list;
	private int plate;
	
	public Producer(LinkedList<Object> list, int i){
		this.list = list;
		this.plate = i;
		
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			synchronized (list) {
				while(list.size() >= maxsize){
					System.out.println("��" + plate + "��������ֹͣ����");
					try {
						list.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				list.add(new Object());
				System.out.println("��" + plate + "������������һ����Ʒ		�ֿ��Ϊ" + list.size());
				list.notifyAll();
			}
		}
	}

}
