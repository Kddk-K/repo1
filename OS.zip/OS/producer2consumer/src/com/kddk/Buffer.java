package com.kddk;

import java.util.LinkedList;

public class Buffer {
	private int maxsize = 3;	//20���洢��Ԫ
	private int full = 0;	//��������ʼ��Ϊ��
	private static Object mutex;	//�ٽ��������ź���
	private LinkedList<Object> list = new LinkedList<>();
	
	public int getMaxsize() {
		return maxsize;
	}
	public void setMaxsize(int maxsize) {
		this.maxsize = maxsize;
	}
	public int getFull() {
		return full;
	}
	public void setFull(int full) {
		this.full = full;
	}
	public static Object getMutex() {
		return mutex;
	}
	public static void setMutex(Object mutex) {
		Buffer.mutex = mutex;
	}
	public LinkedList<Object> getList() {
		return list;
	}
	public void setList(LinkedList<Object> list) {
		this.list = list;
	}
}
