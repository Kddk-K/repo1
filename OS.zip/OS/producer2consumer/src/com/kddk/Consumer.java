package com.kddk;

import java.util.LinkedList;

public class Consumer implements Runnable{
	
	Buffer bf = new Buffer();
	int maxsize = bf.getMaxsize();
	LinkedList<Object> list;
	private int plate;

	public Consumer(LinkedList<Object> list, int i) {
		this.list = list;
		this.plate = i;

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			synchronized (list) {
				if(list.size() <= 0){
					System.out.println("������ֹͣ����");
					try {
						list.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				list.remove();
				System.out.println("��" + plate + "������������һ����Ʒ		�ֿ��Ϊ" + list.size());
				list.notifyAll();
			}
		}
	}
}
