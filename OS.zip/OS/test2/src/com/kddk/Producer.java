package com.kddk;


public class Producer implements Runnable{   
	ProducerAndConsumer queue;   
    public Producer(ProducerAndConsumer s){   
        queue=s;   
    }   

	public void run(){   
        for(int i=0;i<20;i++){   
            char c=(char)(Math.random()*26+'A');   
            queue.inqueue(c);   
            try{   
                Thread.sleep((int)(Math.random()*20));   
            }catch(InterruptedException e){System.out.println(e);}   
        }   
    }   
}  