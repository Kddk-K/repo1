package com.kddk;

public class ProducerAndConsumer {
	
  
	    private int head=0;//��ͷ   
	    private int tail=1;//��β   
	    public final int Num=6;//��������С   
	    public char data[]=new char[Num];   
	    public  synchronized void inqueue(char c){   
	        while((tail+1)%Num==head){  
	        	System.out.println("�������������ȴ�.");
	            try{   
	                this.wait();   
	            }catch(InterruptedException e){System.out.println(e);}   
	               
	        }   
	        this.notify();   
	           
	            data[tail]=c;   
	            tail=(tail+1)%Num;   
	            System.out.println("����:" + c );   
	           
	           
	    }   
	    public  synchronized char outqueue(){   
	        while((head+1)%Num==tail){  
	        	System.out.println("���пգ����ѵȴ�.");
	            try{   
	                this.wait();   
	            }catch(InterruptedException e){System.out.println(e);}   
	        } 
	            this.notify();   
	           
	       
	            head=(head+1)%Num;   
	               
	            System.out.println("���ѣ�"+data[head]);   
	            return data[head];   
	           
	       
	    }   
	}  



	

	
	

	

