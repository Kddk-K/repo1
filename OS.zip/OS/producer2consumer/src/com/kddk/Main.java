package com.kddk;

import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Buffer bf = new Buffer();
		LinkedList<Object> list = bf.getList();
		for (int i = 1; i <= 10; i++) {
			Consumer p1 = new Consumer(list, i);
			new Thread(p1).start();
			Producer p2 = new Producer(list, i);
			new Thread(p2).start();
		}
	}

}
