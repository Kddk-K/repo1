package com.kddk;

public class Consumer implements Runnable{   
	    ProducerAndConsumer queue;
		public Consumer(ProducerAndConsumer s){   
	        queue=s;   
	    }   
	    public void run(){   
	        for(int i=0;i<20;i++){   
	            queue.outqueue();
				try{   
	                Thread.sleep((int)(Math.random()*20));   
	            }catch(InterruptedException e){System.out.println(e);}   
	        }   
	    }   
	}  


